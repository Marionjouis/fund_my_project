<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/index.html.twig */
class __TwigTemplate_eec0772cbecc585cb1a8c9ca393767553348ba5897211e3bccd9d68f473575d8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Fund My ProjectFixtures - Accueil";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"container\">
        <h1>Bienvenue sur Fund My ProjectFixtures</h1>
        <p>Aidez-nous à créer de nouveaux projets chaque jour !</p>
        <div class=\"row\">
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"uploads/project1.jpg\" class=\"card-image-top\" alt=\"Good Girl\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">Good Girl</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Film</a></li>
                        </ul>
                        <p class=\"card-text\">Ce film parle de ...</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"images/placeholder.png\" class=\"card-image-top\" alt=\"Les yeux dans le bus\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">Les yeux dans le bus</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Film</a></li>
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Sport</a></li>
                        </ul>
                        <p class=\"card-text\">Revivez la grande épopée de l'équipe de France de football lors du mondial de football 2010.</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"uploads/project3.jpg\" class=\"card-image-top\" alt=\"Dabado\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">Dabado</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Jeux</a></li>
                        </ul>
                        <p class=\"card-text\">Un jeu fantastique peint à la main. Plongez dans des aventures extra-ordinaires !</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"uploads/project4.jpg\" class=\"card-image-top\" alt=\"DOOSH\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">DOOSH</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Musique</a></li>
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Film</a></li>
                        </ul>
                        <p class=\"card-text\">Venez m'accompagner dans mon projet de création musicale avec clip vidéo !</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Fund My ProjectFixtures - Accueil{% endblock %}

{% block body %}
    <div class=\"container\">
        <h1>Bienvenue sur Fund My ProjectFixtures</h1>
        <p>Aidez-nous à créer de nouveaux projets chaque jour !</p>
        <div class=\"row\">
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"uploads/project1.jpg\" class=\"card-image-top\" alt=\"Good Girl\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">Good Girl</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Film</a></li>
                        </ul>
                        <p class=\"card-text\">Ce film parle de ...</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"images/placeholder.png\" class=\"card-image-top\" alt=\"Les yeux dans le bus\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">Les yeux dans le bus</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Film</a></li>
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Sport</a></li>
                        </ul>
                        <p class=\"card-text\">Revivez la grande épopée de l'équipe de France de football lors du mondial de football 2010.</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"uploads/project3.jpg\" class=\"card-image-top\" alt=\"Dabado\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">Dabado</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Jeux</a></li>
                        </ul>
                        <p class=\"card-text\">Un jeu fantastique peint à la main. Plongez dans des aventures extra-ordinaires !</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
            <article class=\"col-4\">
                <div class=\"card\">
                    <image src=\"uploads/project4.jpg\" class=\"card-image-top\" alt=\"DOOSH\">
                    <div class=\"card-body\">
                        <h5 class=\"card-title\">DOOSH</h5>
                        <ul class=\"badges\">
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Musique</a></li>
                            <li><a href=\"category.html\" class=\"badge badge-pill badge-primary\">Film</a></li>
                        </ul>
                        <p class=\"card-text\">Venez m'accompagner dans mon projet de création musicale avec clip vidéo !</p>
                        <a href=\"project.html\" class=\"btn btn-primary\">
                            <i class=\"fa fa-eye\"></i>
                            Voir plus
                        </a>
                    </div>
                </div>
            </article>
        </div>
    </div>
{% endblock %}
", "default/index.html.twig", "/Users/neness/Sites/fund_my_project/templates/default/index.html.twig");
    }
}
