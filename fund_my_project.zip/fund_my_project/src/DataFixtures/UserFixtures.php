<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class UserFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $marion = new \App\Entity\User();
        $marion->setFirstname("Marion");
        $marion->setLastname("Jouis");
        $marion->setEmail("marion.jouis@gmail.com");
        $marion->setPassword("root");
        $marion->setRoles("user");
        $manager->persist($marion);
        $this->addReference("marion", $marion);

        $manager->flush();
    }
}
