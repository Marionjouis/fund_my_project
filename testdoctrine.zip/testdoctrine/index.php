<?php
require_once "bootstrap.php";

use Entity\Person;


/*
 *
 * INSERT INTO

$person = new Person();
$person ->setFirstname("Pierre");
$person ->setLastname("Jehan");
$person ->setBirthdate(new DateTime("1989-06-29"));

$entityManager->persist($person); // Ajouter l'objet à l'entity manager
$entityManager->flush(); // Executer les requetes SQL

*/

$persons = $entityManager->getRepository(Person::class)->findAll();

/** @var Person $person */
foreach ($persons as $person){
    echo $person->getFirstname();
}
  